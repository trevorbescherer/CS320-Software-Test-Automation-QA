import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * TaskTest.java
 * JUnit 5 unit tests for the Task class.
 * CS 320 - Module Four Milestone
 * Author: Trevor Bescherer
 */
class TaskTest {

    // ── Constructor – happy path ──────────────────────────────────────────────

    @Test
    void testTaskCreatedSuccessfully() {
        Task task = new Task("T001", "Buy Groceries", "Pick up milk, eggs, and bread.");
        assertEquals("T001", task.getTaskId());
        assertEquals("Buy Groceries", task.getName());
        assertEquals("Pick up milk, eggs, and bread.", task.getDescription());
    }

    // ── Task ID validation ────────────────────────────────────────────────────

    @Test
    void testTaskIdNull_ThrowsException() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task(null, "Name", "Description"));
    }

    @Test
    void testTaskIdTooLong_ThrowsException() {
        // 11 characters – exceeds max of 10
        assertThrows(IllegalArgumentException.class,
            () -> new Task("12345678901", "Name", "Description"));
    }

    @Test
    void testTaskIdExactlyTenChars_Allowed() {
        assertDoesNotThrow(() -> new Task("1234567890", "Name", "Description"));
    }

    // ── Name validation ───────────────────────────────────────────────────────

    @Test
    void testNameNull_ThrowsException() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task("T001", null, "Description"));
    }

    @Test
    void testNameTooLong_ThrowsException() {
        // 21 characters – exceeds max of 20
        assertThrows(IllegalArgumentException.class,
            () -> new Task("T001", "123456789012345678901", "Description"));
    }

    @Test
    void testNameExactlyTwentyChars_Allowed() {
        assertDoesNotThrow(() -> new Task("T001", "12345678901234567890", "Description"));
    }

    // ── Description validation ────────────────────────────────────────────────

    @Test
    void testDescriptionNull_ThrowsException() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task("T001", "Name", null));
    }

    @Test
    void testDescriptionTooLong_ThrowsException() {
        // 51 characters – exceeds max of 50
        assertThrows(IllegalArgumentException.class,
            () -> new Task("T001", "Name",
                "123456789012345678901234567890123456789012345678901"));
    }

    @Test
    void testDescriptionExactlyFiftyChars_Allowed() {
        assertDoesNotThrow(() -> new Task("T001", "Name",
            "12345678901234567890123456789012345678901234567890"));
    }

    // ── setName validation ────────────────────────────────────────────────────

    @Test
    void testSetNameUpdatesValue() {
        Task task = new Task("T001", "Old Name", "Description");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    @Test
    void testSetNameNull_ThrowsException() {
        Task task = new Task("T001", "Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
    }

    @Test
    void testSetNameTooLong_ThrowsException() {
        Task task = new Task("T001", "Name", "Description");
        assertThrows(IllegalArgumentException.class,
            () -> task.setName("123456789012345678901")); // 21 chars
    }

    // ── setDescription validation ─────────────────────────────────────────────

    @Test
    void testSetDescriptionUpdatesValue() {
        Task task = new Task("T001", "Name", "Old description.");
        task.setDescription("New description.");
        assertEquals("New description.", task.getDescription());
    }

    @Test
    void testSetDescriptionNull_ThrowsException() {
        Task task = new Task("T001", "Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
    }

    @Test
    void testSetDescriptionTooLong_ThrowsException() {
        Task task = new Task("T001", "Name", "Description");
        assertThrows(IllegalArgumentException.class,
            () -> task.setDescription(
                "123456789012345678901234567890123456789012345678901")); // 51 chars
    }

    // ── Task ID is not updatable (no setter exists) ───────────────────────────

    @Test
    void testTaskIdRemainsUnchanged() {
        Task task = new Task("T001", "Name", "Description");
        // Confirm the ID is stable – Task has no setTaskId() method
        assertEquals("T001", task.getTaskId());
    }
}
