import java.util.HashMap;
import java.util.Map;

/**
 * TaskService.java
 * Provides in-memory CRUD operations for Task objects.
 * CS 320 - Module Four Milestone
 * Author: Trevor Bescherer
 */
public class TaskService {

    // In-memory storage: taskId → Task
    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a new Task to the service.
     *
     * @param task Task to add
     * @throws IllegalArgumentException if task is null or the ID already exists
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task must not be null.");
        }
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException(
                "A task with ID '" + task.getTaskId() + "' already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    /**
     * Deletes the Task with the given ID.
     *
     * @param taskId ID of the task to delete
     * @throws IllegalArgumentException if no task with that ID exists
     */
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException(
                "No task found with ID '" + taskId + "'.");
        }
        tasks.remove(taskId);
    }

    /**
     * Updates the name of the Task with the given ID.
     *
     * @param taskId  ID of the task to update
     * @param newName New name value
     * @throws IllegalArgumentException if no task with that ID exists
     */
    public void updateName(String taskId, String newName) {
        Task task = getTaskOrThrow(taskId);
        task.setName(newName);
    }

    /**
     * Updates the description of the Task with the given ID.
     *
     * @param taskId         ID of the task to update
     * @param newDescription New description value
     * @throws IllegalArgumentException if no task with that ID exists
     */
    public void updateDescription(String taskId, String newDescription) {
        Task task = getTaskOrThrow(taskId);
        task.setDescription(newDescription);
    }

    /**
     * Retrieves the Task with the given ID (read-only lookup).
     *
     * @param taskId ID to look up
     * @return the matching Task
     * @throws IllegalArgumentException if no task with that ID exists
     */
    public Task getTask(String taskId) {
        return getTaskOrThrow(taskId);
    }

    // ── Private helper ────────────────────────────────────────────────────────

    private Task getTaskOrThrow(String taskId) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException(
                "No task found with ID '" + taskId + "'.");
        }
        return task;
    }
}
