/**
 * Task.java
 * Represents a Task object for the mobile application.
 * CS 320 - Module Four Milestone
 * Author: Trevor Bescherer
 */
public class Task {

    private final String taskId;   // unique, not null, max 10 chars, not updatable
    private String name;           // not null, max 20 chars
    private String description;    // not null, max 50 chars

    /**
     * Constructs a Task with the given ID, name, and description.
     *
     * @param taskId      Unique task identifier (max 10 chars, not null)
     * @param name        Task name (max 20 chars, not null)
     * @param description Task description (max 50 chars, not null)
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException(
                "Task ID must not be null and must be 10 characters or fewer.");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException(
                "Name must not be null and must be 20 characters or fewer.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException(
                "Description must not be null and must be 50 characters or fewer.");
        }

        this.taskId      = taskId;
        this.name        = name;
        this.description = description;
    }

    // ── Getters ──────────────────────────────────────────────────────────────

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // ── Setters ────────────

    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException(
                "Name must not be null and must be 20 characters or fewer.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException(
                "Description must not be null and must be 50 characters or fewer.");
        }
        this.description = description;
    }
}
