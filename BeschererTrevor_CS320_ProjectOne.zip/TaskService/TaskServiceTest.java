import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * TaskServiceTest.java
 * JUnit 5 unit tests for the TaskService class.
 * CS 320 - Module Four Milestone
 * Author: Trevor Bescherer
 */
class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    // ── addTask ───────────────────────────────────────────────────────────────

    @Test
    void testAddTask_Success() {
        Task task = new Task("T001", "Buy Groceries", "Pick up milk, eggs, and bread.");
        service.addTask(task);
        assertEquals(task, service.getTask("T001"));
    }

    @Test
    void testAddTask_NullTask_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.addTask(null));
    }

    @Test
    void testAddTask_DuplicateId_ThrowsException() {
        Task task1 = new Task("T001", "First Task", "First description.");
        Task task2 = new Task("T001", "Second Task", "Second description.");
        service.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task2));
    }

    @Test
    void testAddMultipleTasks_UniqueIds_Success() {
        service.addTask(new Task("T001", "Task One", "Description one."));
        service.addTask(new Task("T002", "Task Two", "Description two."));
        assertEquals("Task One", service.getTask("T001").getName());
        assertEquals("Task Two", service.getTask("T002").getName());
    }

    // ── deleteTask ────────────────────────────────────────────────────────────

    @Test
    void testDeleteTask_Success() {
        service.addTask(new Task("T001", "Buy Groceries", "Description."));
        service.deleteTask("T001");
        assertThrows(IllegalArgumentException.class, () -> service.getTask("T001"));
    }

    @Test
    void testDeleteTask_NonExistentId_ThrowsException() {
        assertThrows(IllegalArgumentException.class,
            () -> service.deleteTask("GHOST"));
    }

    @Test
    void testDeleteTask_DoesNotAffectOtherTasks() {
        service.addTask(new Task("T001", "Task One", "Description one."));
        service.addTask(new Task("T002", "Task Two", "Description two."));
        service.deleteTask("T001");
        // T002 should still exist
        assertDoesNotThrow(() -> service.getTask("T002"));
    }

    // ── updateName ────────────────────────────────────────────────────────────

    @Test
    void testUpdateName_Success() {
        service.addTask(new Task("T001", "Old Name", "Description."));
        service.updateName("T001", "New Name");
        assertEquals("New Name", service.getTask("T001").getName());
    }

    @Test
    void testUpdateName_NonExistentId_ThrowsException() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updateName("GHOST", "New Name"));
    }

    @Test
    void testUpdateName_NullValue_ThrowsException() {
        service.addTask(new Task("T001", "Name", "Description."));
        assertThrows(IllegalArgumentException.class,
            () -> service.updateName("T001", null));
    }

    @Test
    void testUpdateName_TooLong_ThrowsException() {
        service.addTask(new Task("T001", "Name", "Description."));
        assertThrows(IllegalArgumentException.class,
            () -> service.updateName("T001", "123456789012345678901")); // 21 chars
    }

    // ── updateDescription ─────────────────────────────────────────────────────

    @Test
    void testUpdateDescription_Success() {
        service.addTask(new Task("T001", "Name", "Old description."));
        service.updateDescription("T001", "Brand new description.");
        assertEquals("Brand new description.", service.getTask("T001").getDescription());
    }

    @Test
    void testUpdateDescription_NonExistentId_ThrowsException() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updateDescription("GHOST", "New description."));
    }

    @Test
    void testUpdateDescription_NullValue_ThrowsException() {
        service.addTask(new Task("T001", "Name", "Description."));
        assertThrows(IllegalArgumentException.class,
            () -> service.updateDescription("T001", null));
    }

    @Test
    void testUpdateDescription_TooLong_ThrowsException() {
        service.addTask(new Task("T001", "Name", "Description."));
        assertThrows(IllegalArgumentException.class,
            () -> service.updateDescription("T001",
                "123456789012345678901234567890123456789012345678901")); // 51 chars
    }

    // ── getTask ───────────────────────────────────────────────────────────────

    @Test
    void testGetTask_NonExistentId_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.getTask("NONE"));
    }

    // ── Task ID is not updatable ──────────────────────────────────────────────

    @Test
    void testTaskId_NotUpdatedByService() {
        service.addTask(new Task("T001", "Name", "Description."));
        // Confirm ID hasn't changed after name and description updates
        service.updateName("T001", "New Name");
        service.updateDescription("T001", "New description.");
        assertEquals("T001", service.getTask("T001").getTaskId());
    }
}
