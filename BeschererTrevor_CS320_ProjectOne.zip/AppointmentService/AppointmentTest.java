import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    // Helper: a future date (1 hour from now)
    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 3_600_000);
    }

    // Helper: a past date (1 hour ago)
    private Date pastDate() {
        return new Date(System.currentTimeMillis() - 3_600_000);
    }

    // -----------------------------------------------------------------------
    // Valid construction
    // -----------------------------------------------------------------------

    @Test
    void testValidAppointmentCreation() {
        Appointment appt = new Appointment("appt01", futureDate(), "Annual checkup");
        assertEquals("appt01", appt.getAppointmentId());
        assertEquals("Annual checkup", appt.getDescription());
        assertNotNull(appt.getAppointmentDate());
    }

    // -----------------------------------------------------------------------
    // Appointment ID constraints
    // -----------------------------------------------------------------------

    @Test
    void testAppointmentIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(null, futureDate(), "Valid description"));
    }

    @Test
    void testAppointmentIdCannotExceedTenCharacters() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345678901", futureDate(), "Valid description"));
    }

    @Test
    void testAppointmentIdExactlyTenCharactersIsAllowed() {
        Appointment appt = new Appointment("1234567890", futureDate(), "Valid description");
        assertEquals("1234567890", appt.getAppointmentId());
    }

    @Test
    void testAppointmentIdIsNotUpdatable() {
        // Appointment has no setAppointmentId method — verified at compile-time.
        // This test confirms the getter still returns the original value.
        Appointment appt = new Appointment("appt01", futureDate(), "Valid description");
        assertEquals("appt01", appt.getAppointmentId());
    }

    // -----------------------------------------------------------------------
    // Appointment Date constraints
    // -----------------------------------------------------------------------

    @Test
    void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("appt01", null, "Valid description"));
    }

    @Test
    void testAppointmentDateCannotBeInThePast() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("appt01", pastDate(), "Valid description"));
    }

    @Test
    void testSetAppointmentDateCannotBeNull() {
        Appointment appt = new Appointment("appt01", futureDate(), "Valid description");
        assertThrows(IllegalArgumentException.class, () ->
                appt.setAppointmentDate(null));
    }

    @Test
    void testSetAppointmentDateCannotBeInThePast() {
        Appointment appt = new Appointment("appt01", futureDate(), "Valid description");
        assertThrows(IllegalArgumentException.class, () ->
                appt.setAppointmentDate(pastDate()));
    }

    @Test
    void testSetAppointmentDateWithFutureDate() {
        Appointment appt = new Appointment("appt01", futureDate(), "Valid description");
        Date newDate = new Date(System.currentTimeMillis() + 7_200_000);
        appt.setAppointmentDate(newDate);
        assertEquals(newDate, appt.getAppointmentDate());
    }

    // -----------------------------------------------------------------------
    // Description constraints
    // -----------------------------------------------------------------------

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("appt01", futureDate(), null));
    }

    @Test
    void testDescriptionCannotExceedFiftyCharacters() {
        String longDesc = "A".repeat(51);
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("appt01", futureDate(), longDesc));
    }

    @Test
    void testDescriptionExactlyFiftyCharactersIsAllowed() {
        String maxDesc = "A".repeat(50);
        Appointment appt = new Appointment("appt01", futureDate(), maxDesc);
        assertEquals(maxDesc, appt.getDescription());
    }

    @Test
    void testSetDescriptionCannotBeNull() {
        Appointment appt = new Appointment("appt01", futureDate(), "Valid description");
        assertThrows(IllegalArgumentException.class, () ->
                appt.setDescription(null));
    }

    @Test
    void testSetDescriptionCannotExceedFiftyCharacters() {
        Appointment appt = new Appointment("appt01", futureDate(), "Valid description");
        assertThrows(IllegalArgumentException.class, () ->
                appt.setDescription("A".repeat(51)));
    }

    @Test
    void testSetDescriptionWithValidValue() {
        Appointment appt = new Appointment("appt01", futureDate(), "Original");
        appt.setDescription("Updated description");
        assertEquals("Updated description", appt.getDescription());
    }
}
