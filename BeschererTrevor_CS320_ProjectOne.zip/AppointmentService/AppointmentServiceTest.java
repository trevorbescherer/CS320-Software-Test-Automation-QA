import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    private AppointmentService service;

    // Helper: a future date (1 hour from now)
    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 3_600_000);
    }

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
    }

    // -----------------------------------------------------------------------
    // addAppointment
    // -----------------------------------------------------------------------

    @Test
    void testAddAppointmentSuccessfully() {
        Appointment appt = new Appointment("appt01", futureDate(), "Team meeting");
        service.addAppointment(appt);
        assertNotNull(service.getAppointment("appt01"));
    }

    @Test
    void testAddMultipleAppointmentsWithUniqueIds() {
        service.addAppointment(new Appointment("appt01", futureDate(), "Meeting one"));
        service.addAppointment(new Appointment("appt02", futureDate(), "Meeting two"));
        assertNotNull(service.getAppointment("appt01"));
        assertNotNull(service.getAppointment("appt02"));
    }

    @Test
    void testAddAppointmentWithDuplicateIdThrowsException() {
        Appointment appt1 = new Appointment("appt01", futureDate(), "First appointment");
        Appointment appt2 = new Appointment("appt01", futureDate(), "Duplicate ID");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () ->
                service.addAppointment(appt2));
    }

    @Test
    void testAddNullAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                service.addAppointment(null));
    }

    // -----------------------------------------------------------------------
    // deleteAppointment
    // -----------------------------------------------------------------------

    @Test
    void testDeleteAppointmentSuccessfully() {
        service.addAppointment(new Appointment("appt01", futureDate(), "To be deleted"));
        service.deleteAppointment("appt01");
        // getAppointment now throws when ID is not found
        assertThrows(IllegalArgumentException.class, () ->
                service.getAppointment("appt01"));
    }

    @Test
    void testDeleteNonexistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                service.deleteAppointment("ghost99"));
    }

    @Test
    void testDeleteOneAppointmentDoesNotAffectOthers() {
        service.addAppointment(new Appointment("appt01", futureDate(), "Keep this"));
        service.addAppointment(new Appointment("appt02", futureDate(), "Delete this"));
        service.deleteAppointment("appt02");
        // appt01 should still be retrievable
        assertNotNull(service.getAppointment("appt01"));
        // appt02 should now throw
        assertThrows(IllegalArgumentException.class, () ->
                service.getAppointment("appt02"));
    }

    @Test
    void testDeletedAppointmentCanBeReaddedWithSameId() {
        service.addAppointment(new Appointment("appt01", futureDate(), "Original"));
        service.deleteAppointment("appt01");
        // Should not throw — the ID is free again
        service.addAppointment(new Appointment("appt01", futureDate(), "Readded"));
        assertNotNull(service.getAppointment("appt01"));
    }

    // -----------------------------------------------------------------------
    // getAppointment
    // -----------------------------------------------------------------------

    @Test
    void testGetNonexistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                service.getAppointment("none"));
    }
}
