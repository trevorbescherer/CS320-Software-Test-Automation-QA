import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    // Add a new appointment; ID must be unique
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment must not be null.");
        }
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("An appointment with this ID already exists.");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Delete an appointment by ID
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("No appointment found with the given ID.");
        }
        appointments.remove(appointmentId);
    }

    // Retrieve an appointment by ID; throws if not found
    public Appointment getAppointment(String appointmentId) {
        Appointment appt = appointments.get(appointmentId);
        if (appt == null) {
            throw new IllegalArgumentException("No appointment found with the given ID.");
        }
        return appt;
    }
}
