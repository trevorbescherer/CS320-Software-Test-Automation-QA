import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;
    private Contact sampleContact;

    @BeforeEach
    void setUp() {
        service = new ContactService();
        sampleContact = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        service.addContact(sampleContact);
    }

    // ── addContact ──────────────────────────────────────────────────────────

    @Test
    void testAddContactSuccess() {
        Contact c = new Contact("ID02", "Jane", "Smith", "1234567890", "456 Oak Ave");
        service.addContact(c);
        assertEquals("Jane", service.getContact("ID02").getFirstName());
    }

    @Test
    void testAddDuplicateContactIdThrows() {
        Contact duplicate = new Contact("ID01", "Alice", "Brown", "9876543210", "789 Pine Rd");
        assertThrows(IllegalArgumentException.class, () -> service.addContact(duplicate));
    }

    @Test
    void testAddNullContactThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.addContact(null));
    }

    // ── deleteContact ───────────────────────────────────────────────────────

    @Test
    void testDeleteContactSuccess() {
        service.deleteContact("ID01");
        assertThrows(IllegalArgumentException.class, () -> service.getContact("ID01"));
    }

    @Test
    void testDeleteNonExistentContactThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("NOTREAL"));
    }

    // ── updateFirstName ─────────────────────────────────────────────────────

    @Test
    void testUpdateFirstNameSuccess() {
        service.updateFirstName("ID01", "Jane");
        assertEquals("Jane", service.getContact("ID01").getFirstName());
    }

    @Test
    void testUpdateFirstNameNotFoundThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updateFirstName("NOTREAL", "Jane"));
    }

    @Test
    void testUpdateFirstNameInvalidThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updateFirstName("ID01", null));
    }

    // ── updateLastName ──────────────────────────────────────────────────────

    @Test
    void testUpdateLastNameSuccess() {
        service.updateLastName("ID01", "Smith");
        assertEquals("Smith", service.getContact("ID01").getLastName());
    }

    @Test
    void testUpdateLastNameNotFoundThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updateLastName("NOTREAL", "Smith"));
    }

    @Test
    void testUpdateLastNameInvalidThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updateLastName("ID01", null));
    }

    // ── updatePhone ─────────────────────────────────────────────────────────

    @Test
    void testUpdatePhoneSuccess() {
        service.updatePhone("ID01", "1234567890");
        assertEquals("1234567890", service.getContact("ID01").getPhone());
    }

    @Test
    void testUpdatePhoneNotFoundThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updatePhone("NOTREAL", "1234567890"));
    }

    @Test
    void testUpdatePhoneInvalidThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updatePhone("ID01", "123"));
    }

    // ── updateAddress ───────────────────────────────────────────────────────

    @Test
    void testUpdateAddressSuccess() {
        service.updateAddress("ID01", "789 Pine Rd");
        assertEquals("789 Pine Rd", service.getContact("ID01").getAddress());
    }

    @Test
    void testUpdateAddressNotFoundThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updateAddress("NOTREAL", "789 Pine Rd"));
    }

    @Test
    void testUpdateAddressInvalidThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> service.updateAddress("ID01", null));
    }
}
