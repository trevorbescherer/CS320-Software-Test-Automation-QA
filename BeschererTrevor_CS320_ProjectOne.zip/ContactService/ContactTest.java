import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    // ── Valid construction ──────────────────────────────────────────────────

    @Test
    void testValidContactCreation() {
        Contact c = new Contact("1234567890", "John", "Doe", "5555555555", "123 Main St");
        assertEquals("1234567890", c.getContactId());
        assertEquals("John",       c.getFirstName());
        assertEquals("Doe",        c.getLastName());
        assertEquals("5555555555", c.getPhone());
        assertEquals("123 Main St",c.getAddress());
    }

    // ── Contact ID ──────────────────────────────────────────────────────────

    @Test
    void testContactIdNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(null, "John", "Doe", "5555555555", "123 Main St"));
    }

    @Test
    void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345678901", "John", "Doe", "5555555555", "123 Main St"));
    }

    @Test
    void testContactIdNotUpdatable() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        // No setContactId method should exist — confirmed by compilation only.
        assertEquals("ID01", c.getContactId());
    }

    // ── First name ──────────────────────────────────────────────────────────

    @Test
    void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", null, "Doe", "5555555555", "123 Main St"));
    }

    @Test
    void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", "FirstNameXY", "Doe", "5555555555", "123 Main St"));
    }

    @Test
    void testSetFirstNameValid() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        c.setFirstName("Jane");
        assertEquals("Jane", c.getFirstName());
    }

    @Test
    void testSetFirstNameNull() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
    }

    @Test
    void testSetFirstNameTooLong() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("FirstNameXY"));
    }

    // ── Last name ───────────────────────────────────────────────────────────

    @Test
    void testLastNameNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", "John", null, "5555555555", "123 Main St"));
    }

    @Test
    void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", "John", "LastNameXYZ", "5555555555", "123 Main St"));
    }

    @Test
    void testSetLastNameValid() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        c.setLastName("Smith");
        assertEquals("Smith", c.getLastName());
    }

    @Test
    void testSetLastNameNull() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
    }

    @Test
    void testSetLastNameTooLong() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("LastNameXYZ"));
    }

    // ── Phone ───────────────────────────────────────────────────────────────

    @Test
    void testPhoneNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", "John", "Doe", null, "123 Main St"));
    }

    @Test
    void testPhoneTooShort() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", "John", "Doe", "555555555", "123 Main St"));
    }

    @Test
    void testPhoneTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", "John", "Doe", "55555555556", "123 Main St"));
    }

    @Test
    void testPhoneNonDigits() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", "John", "Doe", "55555ABCDE", "123 Main St"));
    }

    @Test
    void testSetPhoneValid() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        c.setPhone("1234567890");
        assertEquals("1234567890", c.getPhone());
    }

    @Test
    void testSetPhoneNull() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> c.setPhone(null));
    }

    @Test
    void testSetPhoneInvalid() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123"));
    }

    // ── Address ─────────────────────────────────────────────────────────────

    @Test
    void testAddressNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", "John", "Doe", "5555555555", null));
    }

    @Test
    void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("ID01", "John", "Doe", "5555555555", "1234567890123456789012345678901"));
    }

    @Test
    void testSetAddressValid() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        c.setAddress("456 Oak Ave");
        assertEquals("456 Oak Ave", c.getAddress());
    }

    @Test
    void testSetAddressNull() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
    }

    @Test
    void testSetAddressTooLong() {
        Contact c = new Contact("ID01", "John", "Doe", "5555555555", "123 Main St");
        assertThrows(IllegalArgumentException.class,
            () -> c.setAddress("1234567890123456789012345678901"));
    }
}
